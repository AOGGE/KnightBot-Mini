# CLASS REP AI — WhatsApp Bot Setup Guide
## Built by Tobi Educational Consult

---

## WHAT YOU NEED (all free)
1. Twilio account (free) → twilio.com
2. Render account (free hosting) → render.com
3. Anthropic API key (free credits) → console.anthropic.com
4. Your WhatsApp number

---

## STEP 1 — Get Your Anthropic API Key
1. Go to console.anthropic.com
2. Sign up for free
3. Go to "API Keys" → Create new key
4. Copy the key (starts with sk-ant-)

---

## STEP 2 — Set Up Twilio WhatsApp Sandbox
1. Go to twilio.com → Sign up free
2. In dashboard, go to: Messaging → Try it out → Send a WhatsApp message
3. You'll see a sandbox number (like +1 415 523 8886)
4. On your WhatsApp, send the join code shown (e.g. "join silver-tiger") to that number
5. Share that same join code with your coursemates so they can connect too
6. Keep this page open — you'll need the webhook URL field later

---

## STEP 3 — Deploy to Render (Free Hosting)
1. Go to render.com → Sign up free
2. Click "New +" → "Web Service"
3. Choose "Deploy manually" or connect your GitHub
4. Upload these bot files OR connect to a GitHub repo containing them
5. Set these settings:
   - Name: classrep-ai
   - Environment: Node
   - Build Command: npm install
   - Start Command: npm start
6. Add Environment Variables (click "Environment"):
   - ANTHROPIC_API_KEY = your key from Step 1
   - CR_NUMBER = whatsapp:+234XXXXXXXXXX (your WhatsApp number with country code)
   - CR_PASSWORD = tobi2025 (or choose your own)
7. Click "Create Web Service"
8. Wait ~2 minutes. Copy the URL it gives you (like https://classrep-ai.onrender.com)

---

## STEP 4 — Connect Twilio to Your Bot
1. Go back to Twilio → WhatsApp Sandbox settings
2. In "When a message comes in" field, paste:
   https://classrep-ai.onrender.com/webhook
3. Make sure method is set to HTTP POST
4. Click Save

---

## STEP 5 — Test It!
Send "hello" to the Twilio sandbox number on WhatsApp.
You should get a reply from CLASS REP AI! 🎓

---

## CR COMMANDS (only your number can use these)
Send these from YOUR WhatsApp number to control the bot:

| Command | What it does |
|---------|-------------|
| /help | Show all CR commands |
| /status | Check bot status |
| /post Your message here | Post an announcement |
| /remind Your reminder here | Post a reminder |
| /tutor on PSY 102 | Activate tutor mode for PSY 102 |
| /tutor on | Activate tutor mode for all courses |
| /tutor off | Deactivate tutor mode |

---

## STUDENT COMMANDS (anyone can use)
| Command | What it does |
|---------|-------------|
| hello / hi / hey | Get welcome message & menu |
| !help | Show help menu |
| !news | See latest announcements |
| !courses | List all 8 courses |
| !gpa | UNILORIN GPA system explained |
| Any question | AI answers it! |

---

## SHARING WITH COURSEMATES
Share this message in your class WhatsApp group:

"Hey everyone! 👋 CLASS REP AI is now live on WhatsApp!

To connect:
1. Save this number: [Twilio sandbox number]
2. Send this message to it: join [your-join-code]
3. Then ask it anything about our courses, exams, GPA — it's available 24/7! 🎓

Powered by Tobi Educational Consult"

---

## NOTES
- Free Render hosting may sleep after 15 mins of inactivity (first reply might be slow)
- Twilio sandbox is free but requires each user to send the join code once
- For a permanent WhatsApp number without the join code, you'd need to apply for WhatsApp Business API (costs money)
- Your Anthropic free credits give you plenty of messages to start

